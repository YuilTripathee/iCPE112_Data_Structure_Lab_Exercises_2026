#include <stdio.h>
//Write a program to determine the second(2nd) largest number in the array
int largest(int arr[], int n){
    int i;
    int large = arr[0];
    for(i=0;i<n;i++){
        if(large < arr[i]){
            large = arr[i];
        }
    }
    return large;
}

int seclargest(int arr[], int n, int large){
    int i;
    int large2 = arr[0];
    //We're going back in
    for(i=0;i<n;i++){
        if(arr[i] != large){
            if(large2 < arr[i]){
                large2 = arr[i];
            }
        }
    }
    return large2;
}


int main(){
    int i, n, arr[10];
    int large, large2;

    //Specify array total
    scanf("%d", &n);

    for(i=0;i<n;i++)
    {
        //Add numbers into the array
        scanf("%d", &arr[i]);
    }

    large = largest(arr,n);
    large2 = seclargest(arr,n,large);

    printf("The 2nd Largest number is: %d", large2);
    return 0;
}