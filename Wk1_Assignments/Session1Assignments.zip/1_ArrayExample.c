#include <stdio.h>
//Write a program to determine the smallest number in the array
int smallest(int arr[], int n){
    int i;
    int small = arr[0];
    for(i=0;i<n;i++){
        if(small > arr[i]){
            small = arr[i];
        }
    }
    return small;
}

int main(){
    int i, n, arr[10];
    int small;

    //Specify array total
    scanf("%d", &n);

    for(i=0;i<n;i++)
    {
        //Add numbers into the array
        scanf("%d", &arr[i]);
    }

    //Call Smallest function
    small = smallest(arr,n);

    printf("The Smallest number is: %d", small);
    return 0;
}

