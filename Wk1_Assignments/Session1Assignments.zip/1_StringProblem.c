#include <stdio.h>
//Write a program to determine length of a string
int strlength(char arr[]){
    int i = 0;
    while(arr[i] != '\0'){
        i++;
    }
    return i;
}

int main(){
    int n;
    char arr[10];

    //Specify array total
    scanf("%s", &arr);
    n = strlength(arr);
    
    printf("%d",n);
    //printf("%s",arr);
}