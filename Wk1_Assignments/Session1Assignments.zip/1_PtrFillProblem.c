#include <stdio.h>
#include <stdlib.h>

void fillptr(int *p, int i){
    *p = i+1;
}

//Write a program to allocate space and fill it with numbers (1-9)
int main(){
    int i, n;
    scanf("%d",&n);

    int *ptr = malloc(n * sizeof(int));

    if(ptr == NULL){
        //Allocation failure
        return 1;
    }

    for(i=0;i<n;i++){
        fillptr(&ptr[i],i);
    }

    for(i=0;i<n;i++){
        printf("%d ",ptr[i]);
    }

    free(ptr);
    ptr=NULL;
    return 0;
}